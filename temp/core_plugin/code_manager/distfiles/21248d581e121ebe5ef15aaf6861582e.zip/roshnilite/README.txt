
Installing Roshnilite theme
---------------------

Please unzip the theme Roshnilite in your moodle theme folder.Now you can safely install the theme.
If you are already logged in just refreshing the browser should trigger your Moodle
site to begin the install 'Plugins Check'.

If not then navigate to Administration > Notifications.

Once your theme is successfully installed you can select it and begin to modify
it using the custom settings page found by navigating to...
Administration > Site Administration > Appearance > Themes > Roshnilite
from the list of theme names that appear at this point in the side block.
Goto Administration > Site Administration > Front page > Front Page Settings
Please choose none option none for Front page, Front page items when logged in.
