<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Moodle's roshnilite theme, an example of how to make a Bootstrap theme
 *
 * DO NOT MODIFY THIS THEME!
 * COPY IT FIRST, THEN RENAME THE COPY AND MODIFY IT INSTEAD.
 *
 * For full information about creating Moodle themes, see:
 * http://docs.moodle.org/dev/Themes_2.0
 *
 * @package    theme_roshnilite
 * @copyright  2015 dualcube {@link http://dualcube.com}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
// Get the HTML for the settings bits.
$html = theme_roshnilite_get_html_for_settings($OUTPUT, $PAGE);
$PAGE->requires->css('/theme/roshnilite/css/font-awesome.min.css');
$PAGE->requires->css('/theme/roshnilite/css/styles.css');
GLOBAL $USER, $CFG;
// Set default (LTR) layout mark-up for a two column page (side-pre-only).
$regionmain = 'span9 pull-right two-column-main'; /* changes classname two-column-main */
$sidepre = 'span3 desktop-first-column two-column-sidebar'; /* changes classname two-column-sidebar */
// Reset layout mark-up for RTL languages.
if (right_to_left()) {
    $regionmain = 'span9 two-column-main'; /* changes classname */
    $sidepre = 'span3 pull-right two-column-sidebar'; /* changes classname */
}

echo $OUTPUT->doctype() ?>
<html <?php echo $OUTPUT->htmlattributes(); ?>>
<head>
    <title><?php echo $OUTPUT->page_title(); ?></title>
    <?php echo $OUTPUT->standard_head_html() ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="image/x-icon" rel="shortcut icon" href="<?php echo $OUTPUT->favicon(); ?>">
	<?php 
        $PAGE->requires->js('/theme/roshnilite/js/jquery-1.11.1.min.js', true);
        $PAGE->requires->js('/theme/roshnilite/js/bootstrap.min.js', true);
        $PAGE->requires->js('/theme/roshnilite/js/jquery.bxslider.min.js', true);
        $PAGE->requires->js('/theme/roshnilite/js/jquery.scroll.js', true);
        $PAGE->requires->js('/theme/roshnilite/js/engine.js', true);
    ?>
</head>

<body <?php echo $OUTPUT->body_attributes('two-column'); ?>>

<?php echo $OUTPUT->standard_top_of_body_html() ?>

<header class="navbar navbar-fixed-top<?php echo $html->navbarclass ?> moodle-has-zindex">
    <div class="inner-header">
        <nav class="navbar-inner">
            <div class="container">
                <a class="inner-logo logo-text" href="<?php echo $CFG->wwwroot;?>"></a>
                 <?php echo $OUTPUT->lang_menu(); ?>
                <?php if (!isloggedin()) { ?>
                    <a href="<?php echo $CFG->wwwroot; ?>/login/index.php" class="btn-2"><?php echo get_string('login');?></a>
<?php
} else if (isguestuser()) { ?>
                <div class="usermenu">
                    <div>
                        <ul class="menubar">
                            <li>
                                <a href="javascript:void(0);">
                                    <span class="userbutton">
                                        <span>
                                            <span class="avatar current">
                                                <?php echo $OUTPUT->user_profile_picture(); ?>
                                            </span>
                                        </span>
                                        <span>Hi, <?php echo $USER->firstname ." ". $USER->lastname; ?></span>
                                    </span>
                                </a>
                            </li>
                        </ul>
                        <ul class="menu">
                            <li>
                                <a href="<?php echo $CFG->wwwroot; ?>/login/logout.php"><span>
                                <?php echo get_string('logout');?></span></a>
                            </li>
                        </ul>
                    </div>
                </div>
<?php
} else if (!isloggedin() or !isguestuser()) { ?>
                <div class="usermenu">
					<div>
						<ul class="menubar">
							<li>
								<a href="javascript:void(0);">
									<span class="userbutton">
										<span>
											<span class="avatar current">
												<?php echo $OUTPUT->user_profile_picture(); ?>
											</span>
										</span>
										<span>Hi, <?php echo $USER->firstname ." ". $USER->lastname; ?></span>
									</span>
								</a>
							</li>
						</ul>
						<ul class="menu">
							<li>
								<a href="<?php echo $CFG->wwwroot; ?>/user/edit.php"><span><?php echo get_string('profile');?></span></a>
							</li>
							<li>
								<a href="<?php echo $CFG->wwwroot.'/course/index.php';?>"><span><?php echo get_string('courses');?></span></a>
							</li>
							<li>
								<a href="<?php echo $CFG->wwwroot; ?>/login/logout.php"><span><?php echo get_string('logout');?></span></a>
							</li>
						</ul>
					</div>
    				</div>
<?php
}
?>
            </div>
        </nav>
    </div>
</header>

<div id="page">
    <?php if ($CFG->version >= 2015051100) {
        echo $OUTPUT->full_header();
} else {
?>
    <header id="page-header" class="clearfix">
        <div id="page-navbar" class="clearfix">
            <div class = "container">
                <div class="row">
                    <nav class="breadcrumb-nav"><?php echo $OUTPUT->navbar(); ?></nav>
                    <div class="breadcrumb-button"><?php echo $OUTPUT->page_heading_button(); ?></div>
                </div>
            </div>
        </div>
        <div id="course-header">
            <?php echo $OUTPUT->course_header(); ?>
        </div>
    </header>
<?php
}
?>
    <div id="page-content" class="row-fluid background-grey">
    	<div class="container">
        <section id="region-main" class="<?php echo $regionmain; ?> no-brodrer">
            <?php
            echo $OUTPUT->course_content_header();
            echo $OUTPUT->main_content();
            echo $OUTPUT->course_content_footer();
            ?>
        </section>
        <?php echo $OUTPUT->blocks('side-pre', $sidepre);?>
      </div> 
    </div>
    <?php require('footer.php'); echo $OUTPUT->standard_end_of_body_html() ?>
</div>
</body>
</html>
